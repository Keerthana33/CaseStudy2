﻿using ServiceRequestManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace ServiceRequestManagement.Controllers
{
    public class LoginController : Controller
    {
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                using (SRMSEntities2 db = new SRMSEntities2())
                {
                    var obj = db.LoginDetails.Where(a => a.LanId.Equals(model.LanId) && a.Password.Equals(model.Password)).FirstOrDefault();
                    var obj2=db.ManagerDetails.Where(a => a.LanId.Equals(model.LanId) && a.Password.Equals(model.Password)).FirstOrDefault();
                    
                    try
                    {
                        if (obj != null)
                        {
                            Session["LanId"] = obj.LanId.ToString();
                            Session["Password"] = obj.Password.ToString();
                            return RedirectToAction("ServiceHome", "ServiceHome");
                        }
                        else if(obj2!= null)
                        {
                            Session["LanId"] = obj2.LanId.ToString();
                            Session["Password"] = obj2.Password.ToString();
                            return RedirectToAction("ManagingHome", "ManagingHome");
                        }
                        else
                        {
                            ViewBag.Error = "Enter Valid Lanid Or Password";
                            return View();
                        }
                    }
                    catch (Exception ex)
                    {

                        Response.Write(ex.Message);
                    }

                }

            }
            return View(model);
        }
       
    }
}