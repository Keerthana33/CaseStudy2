﻿using Newtonsoft.Json;
using ServiceRequestManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace ServiceRequestManagement.Controllers
{
    public class ManagingHomeController : Controller
    {
        public SRMSEntities2 database = new SRMSEntities2();
        // GET: ManagingHome
        public ActionResult ManagingHome()
        {

            if (Session["LanId"] != null)
            {

                ListModel model = new ListModel();
                //UserDetail table = new UserDetail();
                model.userdetail = database.UserDetails.ToList();
                model.pendinglist = database.PendingLists.ToList();
                model.completedlist = database.CompletedLists.ToList();

                return View("ManagingHome", model);

            }
            else
            {
                return RedirectToAction("Login", "Login");
            }
        }
        //public ActionResult Approve(int? id,ServiceRequestFormModel model)
        //{
        //    try
        //    {
        //        if (id == null)
        //        {
        //            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //        }

        //        string status = "Pending";
        //        PendingList table = new PendingList();
        //        table.RequestId = id.GetValueOrDefault();
        //        table.RequestedBy = model.RequestedBy;
        //        table.RequestedOn = model.RequestDate;
        //        table.ServiceRequired = model.Need_requested;
        //        table.Status = status;
        //        database.PendingLists.Add(table);
        //        database.SaveChanges();
        //        UserDetail detail = database.UserDetails.Find(id);
        //        database.UserDetails.Remove(detail);
        //        database.SaveChanges();
        //        return RedirectToAction("ManagerHome");
        //    }
        //    catch (DbEntityValidationException ex)
        //    {
        //        var result = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
        //        foreach (var item in result)
        //        {
        //            MessageBox.Show(item);
        //        }
        //    }
        //    return View();
        //}

        public ActionResult Charts()
        {
            List<int> list = new List<int>();
            var result = database.UserDetails.Count();
            var result2 = database.PendingLists.Count();
            var result3 = database.CompletedLists.Count();
            var total = result + result2 + result3;
            ViewBag.result = result;
            ViewBag.result2 = result2;
            ViewBag.result3 = result3;
            ViewBag.total = total;
            List<DataPoint> dataPoints = new List<DataPoint>{
                new DataPoint(10, total),
                new DataPoint(20, result),
                new DataPoint(30, result2),
                new DataPoint(40, result3)
                           };

            ViewBag.DataPoints = JsonConvert.SerializeObject(dataPoints);
            return View();
        }


        public ActionResult Approve(int? RequestId)
        {

            if (RequestId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail table = database.UserDetails.Find(RequestId);
            if (table == null)
            {
                return HttpNotFound();
            }
            return View(table);
        }
        [HttpPost]
        public ActionResult Approve(int RequestId)
        {
            var result = database.UserDetails.Find(RequestId);
            string status = "Pending";
            PendingList list = new PendingList();
            list.RequestId = result.RequestId;
            list.RequestedOn = result.RequestedOn;
            list.RequestedBy = result.RequestedBy;
            list.ServiceRequired = result.ServiceRequired;
            list.Status = status;
            database.PendingLists.Add(list);
            UserDetail detail = database.UserDetails.Find(RequestId);
            database.UserDetails.Remove(detail);
            database.SaveChanges();
            return RedirectToAction("ManagingHome");
        }
        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon(); // it will clear the session at the end of request
            return RedirectToAction("Login", "Login");
        }
    }
}