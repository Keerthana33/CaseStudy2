﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Excel = Microsoft.Office.Interop.Excel;
using ServiceRequestManagement.Models;
using System.IO;
using System.Web.Security;
using System.Data.Entity.Validation;
using System.Windows.Forms;
using System.Data.Entity.Core.Objects;
using System.Net;


namespace ServiceRequestManagement.Controllers
{


    public class ServiceHomeController : Controller
    {
        public SRMSEntities2 database = new SRMSEntities2();
        // GET: ServiceHome
        public ActionResult ServiceHome()
        {
            if (Session["LanId"] != null)
            {
                SRMSEntities2 database = new SRMSEntities2();
                ListModel model = new ListModel();
                //UserDetail table = new UserDetail();
                model.userdetail = database.UserDetails.ToList();
                model.pendinglist = database.PendingLists.ToList();
                model.completedlist = database.CompletedLists.ToList();
                return View("ServiceHome", model);
            }
            else
            {
                return RedirectToAction("Login", "Login");
            }
        }


        [HttpGet]
        public ActionResult ServiceFileUpload()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UploadFiles(IEnumerable<HttpPostedFileBase> files)
        {
            foreach (var file in files)
            {
                string filePath = Guid.NewGuid() + Path.GetExtension(file.FileName);
                file.SaveAs(Path.Combine(Server.MapPath("~/UploadedFiles"), filePath));
                //Here you can write code for save this information in your database if you want
            }
            return Json("file uploaded successfully");
        }
        [HttpPost]
        public ActionResult ServiceFileUpload(HttpPostedFileBase file)
        {
            try
            {
                if (file.ContentLength > 0)
                {
                    if (file.FileName.EndsWith(".xlsx"))
                    {

                        string _FileName = Path.GetFileName(file.FileName);
                        string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
                        file.SaveAs(_path);
                       Excel.Application app = new Excel.Application();
                        Excel.Workbook workbook = app.Workbooks.Open(_path);
                        Excel.Worksheet worksheet = workbook.ActiveSheet;
                        Excel.Range range = worksheet.UsedRange;
                       
                        TempData["RequestDate"] = ((Excel.Range)range.Cells[1, 1]).Text;
                        TempData["RequestedBy"] = ((Excel.Range)range.Cells[1, 2]).Text;
                        TempData["Site"] = ((Excel.Range)range.Cells[1, 3]).Text;
                        TempData["Date_Needed"] = ((Excel.Range)range.Cells[1, 4]).Text;
                        TempData["Need_requested"] = ((Excel.Range)range.Cells[1, 5]).Text;
                        TempData["AdditionalInformation"] = ((Excel.Range)range.Cells[1, 6]).Text;


                        return RedirectToAction("ServiceFormDisplay");
                    }
                    else
                    {
                        ViewBag.Message = "Select xlsx file";
                        return View();

                    }
                }
                return View();
            }
            catch
            {
                ViewBag.Message = "File upload failed!!";
                return View();
            }

        }
       
        public ActionResult ServiceFormDisplay()
        {
                     
            ServiceRequestFormModel columns = new ServiceRequestFormModel();
            columns.RequestDate = DateTime.Parse(TempData["RequestDate"].ToString());
            columns.RequestedBy = TempData["RequestedBy"].ToString();
            columns.Site = TempData["Site"].ToString();
            columns.Date_Needed = DateTime.Parse(TempData["Date_Needed"].ToString());
            columns.Need_requested = TempData["Need_requested"].ToString();
            columns.AdditionalInformation = TempData["AdditionalInformation"].ToString();
            return View(columns);
        }
        [HttpPost]
        public ActionResult ServiceFormDisplay(ServiceRequestFormModel model)
        {
            SRMSEntities2 database = new SRMSEntities2();
           
            if (ModelState.IsValid)
            {
                try
                {
                    ObjectParameter obj = new ObjectParameter("Id", typeof(int));
                    string status = "Pending For Approval";
                    database.UspAddUserDetails(model.RequestedBy,model.RequestDate, model.Site, model.Date_Needed, model.Need_requested, model.AdditionalInformation,status,obj);
                    //table.RequestedOn = model.RequestDate;
                    //table.RequestedBy = model.RequestedBy;
                    //table.PageWhereServiceNeeded = model.Site;
                    //table.DateNeeded = model.Date_Needed;
                    //table.ServiceRequired = model.Need_requested;
                    //table.AdditionalInformation = model.AdditionalInformation;
                    int result = Convert.ToInt32(obj.Value);
                    MessageBox.Show("The request Id is " + result);
                    database.SaveChanges();
                    return RedirectToAction("ServiceHome");
                }
                catch(DbEntityValidationException ex)
                {
                    var result = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                    foreach (var item in result)
                    {
                        MessageBox.Show(item);
                    }
                }
                }
            return View(model);
            }

        public ActionResult Complete(int? RequestId)
        {
            if (RequestId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PendingList table1 = database.PendingLists.Where(x=>x.RequestId== RequestId).FirstOrDefault();
            if (table1 == null)
            {
                return HttpNotFound();
            }
            return View(table1);
        }
        [HttpPost]
        public ActionResult Complete(int RequestId)
        {
            var result = database.PendingLists.Where(x=>x.RequestId==RequestId).FirstOrDefault();
            string status = "Completed";
            CompletedList list = new CompletedList();
            list.RequestId = result.RequestId;
            list.RequestedOn = result.RequestedOn;
            list.RequestedBy = result.RequestedBy;
            list.CompletedOn = DateTime.Now;
            list.ServiceProvided = "Service is Provided for "+result.ServiceRequired;
            list.Status = status;
            database.CompletedLists.Add(list);
            PendingList detail = database.PendingLists.Where(x => x.RequestId == RequestId).FirstOrDefault();
            database.PendingLists.Remove(detail);
            database.SaveChanges();
            return RedirectToAction("ServiceHome");
        }
        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon(); // it will clear the session at the end of request
            return RedirectToAction("Login", "Login");
        }
    }
}

