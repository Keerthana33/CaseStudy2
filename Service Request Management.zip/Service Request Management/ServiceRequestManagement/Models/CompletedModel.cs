﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceRequestManagement.Models
{
    public class CompletedModel
    {
        public int RequestId { get; set; }
        public string RequestedBy { get; set; }
        public DateTime RequestedOn { get; set; }
        public DateTime CompletedOn { get; set; }
        public string ServiceProvided { get; set; }
        public string Status { get; set; }
    }
}