﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceRequestManagement.Models
{
    public class ListModel
    {
        public IEnumerable<UserDetail> userdetail { get; set; }
        public IEnumerable<PendingList> pendinglist { get; set; }
        public IEnumerable<CompletedList> completedlist { get; set; }
    }
}