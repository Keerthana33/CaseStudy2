﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceRequestManagement.Models
{
    public class LoginModel
    {
        [Required(ErrorMessage = "Please enter correct LanId")]
        [Display(Name = "LanId")]
        public string LanId { get; set; }

        [Required(ErrorMessage = "Please enter correct Password")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}