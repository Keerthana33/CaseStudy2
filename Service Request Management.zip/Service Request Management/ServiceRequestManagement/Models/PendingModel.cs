﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceRequestManagement.Models
{
    public class PendingModel
    {
        public int requestId { get; set; }
        public string RequestedBy { get; set; }
        public DateTime RequestedOn { get; set; }
        public string ServiceRequired { get; set; }
        public DateTime CompletedOn { get; set; }
        public string status { get; set; }
    }
}