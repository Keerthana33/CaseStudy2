﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceRequestManagement.Models
{
    public class ServiceRequestFormModel
    {
        public int RequestId { get; set; }
        public DateTime RequestDate { get; set; }
        public string RequestedBy { get; set; }
        public string Site { get; set; }
        public DateTime Date_Needed { get; set; }
        public string Need_requested { get; set; }
        public string AdditionalInformation { get; set; }
        public string status { get; set; }

    }
}