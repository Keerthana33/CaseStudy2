﻿$(function () {
    $("#tabs").tabs();
});